@ApiStatus.Experimental
package net.fabricmc.fabric.api.client.gametest.v1.world;

import org.jetbrains.annotations.ApiStatus;
